import streamlit as st
import re

# Function to parse details from header (filename)
def parse_header(header_line):
    size_match = re.search(r"(\d{3,4})\s*x\s*(\d{3,4})", header_line)
    bleed_match = re.search(r"(\d{1,2})mm\s*BLEED", header_line, re.IGNORECASE)
    material_match = re.search(r"(FABRIC TEXT BACKLIT|VINYL|MESH|PAPER|CANVAS)", header_line, re.IGNORECASE)

    return {
        "size": size_match.group(0) if size_match else "Not found",
        "bleed": bleed_match.group(1) + "mm" if bleed_match else "Not found",
        "material": material_match.group(1).strip().upper() if material_match else "Not found"
    }

# Streamlit app UI
st.title("📄 PDF Filename Checker")
st.write("Upload a PDF with a descriptive filename. This app will extract size, bleed, and material type from the file name.")

uploaded_pdf = st.file_uploader("Upload your PDF file here", type=["pdf"])

if uploaded_pdf is not None:
    file_name_header = uploaded_pdf.name.replace(".pdf", "")
    st.subheader("Filename Header:")
    st.code(file_name_header)

    # Parse filename
    header_details = parse_header(file_name_header)

    # Show parsed details
    st.subheader("Parsed Values:")
    st.write(f"**Size:** {header_details['size']}")
    st.write(f"**Bleed:** {header_details['bleed']}")
    st.write(f"**Material:** {header_details['material']}")

    # Optional validation
    if "Not found" in header_details.values():
        st.error("⚠️ One or more values could not be extracted. Please ensure the filename includes 'SIZE x SIZE', '25mm BLEED', and 'MATERIAL'.")
    else:
        st.success("✅ All fields successfully extracted!")
